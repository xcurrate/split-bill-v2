'use client';

import { useState, useEffect, useCallback } from 'react';

export function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((prev: T) => T)) => void] {
  // State to store our value
  const [storedValue, setStoredValue] = useState<T>(initialValue);
  const [isInitialized, setIsInitialized] = useState(false);

  // Initialize from localStorage on mount
  useEffect(() => {
    if (typeof window === 'undefined') return;
    
    try {
      const item = window.localStorage.getItem(key);
      if (item) {
        setStoredValue(JSON.parse(item));
      }
    } catch (error) {
      console.warn(`Error reading localStorage key "${key}":`, error);
    }
    setIsInitialized(true);
  }, [key]);

  // Return a wrapped version of useState's setter function that persists to localStorage
  const setValue = useCallback((value: T | ((prev: T) => T)) => {
    try {
      // Allow value to be a function so we have same API as useState
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      
      // Save state
      setStoredValue(valueToStore);
      
      // Save to localStorage
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      }
    } catch (error) {
      console.warn(`Error setting localStorage key "${key}":`, error);
    }
  }, [key, storedValue]);

  return [storedValue, setValue];
}

export function useLocalStorageObject<T extends object>(
  key: string,
  initialValue: T
): [T, (updates: Partial<T> | ((prev: T) => Partial<T>)) => void] {
  const [storedValue, setStoredValue] = useLocalStorage<T>(key, initialValue);

  const updateValue = useCallback((updates: Partial<T> | ((prev: T) => Partial<T>)) => {
    setStoredValue((prev) => {
      const updatesToApply = updates instanceof Function ? updates(prev) : updates;
      return { ...prev, ...updatesToApply };
    });
  }, [setStoredValue]);

  return [storedValue, updateValue];
}
